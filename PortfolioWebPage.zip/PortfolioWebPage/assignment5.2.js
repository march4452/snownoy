let level = 23; 
let accuracyRate = 0.99; 
let name = "Thanakorn";
 alert(name);
console.log(name);
console.log(typeof(level)); 

// Global and function scope
// var carName = "Volvo";

// myFunction();
// function myFunction() {
//   var carName_2 = "BMW";
//   console.log(carName);
//   console.log(carName_2);
// }
// console.log(carName);
// console.log(carName_2);

// block scope
// {
//     var x = "Volvo";
//     let y = "BMW";
// }
// console.log(x);
// console.log(y);

//Redeclaring variables
// var x = 5;
// let y = 10;
// {
//     var x = 2;
//     let y = 20;
//     console.log(y);
// }
// console.log(x);
// console.log(y);

// number
// var enrollment = 99; 
// var mediangrade = 2.8; 
// var credits = 5 + 4 + (2 * 3);

// string
// var mName = "Media Technology" ;
// var sName = mName.substring(0, mName.indexOf(" "));
// var len = mName.length; // 16 
// console.log(sName);
// console.log(len);

// var magicNum = parseInt("42"); 	
// var mystery = parseFloat("Am I a number?"); 
// console.log(typeof(magicNum));

// access characters
// var puppyCount = "10"+ " puppies!";
// var firstLetter = puppyCount[0];
// console.log(typeof(firstLetter));

// special values
// var foo = null; 
// var bar = 9; 
// var blue; 
// console.log(foo);
// console.log(bar);
// console.log(blue);

// if/else statements
// var a = 5;
// if (a == 5){
// 	console.log("a = 5");
// }else{
// 	console.log("a= ??");
// }

// function
// function myFunction() { 
//     alert("Hello!"); 
//     alert("Your browser says hi!"); 
// }
// myFunction();